/*
if you have already used ImGuiIO &io = ImGui::GetIO();
you can delete

there should be no repetition --> ImFontConfig font_cfg;

change rus to your font name in the .h file 

unsigned char inter[] = {

that means instead of Rus put inter



let's talk about getGlyph:
there are many names

here are a couple of them
characters will be Chinese and English:

GetGlyphRangesChinese());

Cyrillic:
GetGlyphRangesCyrillic());

Korean:
GetGlyphRangesKorean());

Japan:
GetGlyphRangesJapanese());

Arabic:
GetGlyphRangesArabic());


ImGui library has a vast number of glyphs
you can do a lot of things using your imagination, you will be limited by whether the font supports your characters or not :)



*/


ImGuiIO &io = ImGui::GetIO();
        
        ImFontConfig font_cfg;
        ImFont *imFontRus;
        imFontRus = io.Fonts->AddFontFromMemoryTTF(&Rus, sizeof Rus, 32.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());
        